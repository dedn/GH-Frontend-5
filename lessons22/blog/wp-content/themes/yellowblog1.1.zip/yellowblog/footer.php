<footer>
    <div class="container">
        <span class="copyright"><a href="#">© Copyright 2012</a></span>
        <ul class="social-networks">

            <li><a href="<?php echo get_theme_mod('social_links_facebook'); ?>"><span class="fa fa-facebook fa-2x"></span></a></li>
             <li><a href="<?php echo get_theme_mod('social_links_twitter'); ?>"><span class="fa fa-twitter fa-2x"></span></a></li>
            <li><a href="<?php echo get_theme_mod('social_links_linkedin'); ?>"><span class="fa fa-linkedin fa-2x"></span></a></li>
        </ul>
    </div>
</footer>